<?php

/**
 * Defaults: Carousel Item
 */

return array(
	'id'               => '',
	'class'            => '',
	'style'            => ''
);